package com.jsp.springpretest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPretestApplicationTests {

	@Test
	void contextLoads() {
	}

}
