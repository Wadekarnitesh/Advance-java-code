package com.jsp.springpretest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPretestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPretestApplication.class, args);
	}

}
