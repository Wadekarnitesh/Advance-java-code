package com.jsp.RespnseEntityWithException1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RespnseEntityWithException1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
