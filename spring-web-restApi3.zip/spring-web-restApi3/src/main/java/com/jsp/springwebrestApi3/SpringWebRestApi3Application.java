package com.jsp.springwebrestApi3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebRestApi3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebRestApi3Application.class, args);
	}

}
