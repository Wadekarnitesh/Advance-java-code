package com.jsp.spring_web_restApi4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebRestApi4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
